##### Opendev - Team n°X
-----

Replace this sentence by a description of the pull request content.
Tell me about the "why" you did this pull request instead of the "how"
you did it (I can see that in the source code).
