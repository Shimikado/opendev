package gameframework.game;

public interface Game {
	public void start();

}
