/**
 * Main package of the game framework
 */
package gameframework;